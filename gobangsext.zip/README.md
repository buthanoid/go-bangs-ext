# go-bangs-ext
Browser Extension to suggest urls in the omnibox when the user enter bangs keywords
